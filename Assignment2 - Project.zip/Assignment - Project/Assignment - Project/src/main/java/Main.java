public class Main {

    //This is the main class here we created the animalhotel object and called the method start
    public static void main(String[] args){
        AnimalHotel AnimalObj=new AnimalHotel();
        AnimalObj.start();
    }


}